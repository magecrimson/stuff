#!/bin/sh
reset

./SRBMiner-MULTI --algorithm randomepic --pool crimson-pool.com:3416 --cpu-threads 0 --disable-gpu 
